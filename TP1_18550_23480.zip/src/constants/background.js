export const BACKGROUND_FLOOR = 210
