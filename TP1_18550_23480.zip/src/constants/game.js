export const GAME_DURATION = 99

export const DEBUG = false

export const GAME_RESULT = {
    WIN : 1,
    DRAW: 0,
}