import { ImmortalFight } from "./ImmortalFight.js"




window.addEventListener("load", function () {
  new ImmortalFight().start()  
})

